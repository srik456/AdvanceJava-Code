package corejava1;

public class TestEmployee {
	public static void main(String args[]){
		/*Employee.showCount();
		Employee e1=new Employee(1,"Anita",2000);
		e1.display();
		e1.calculateGross();
		e1.setBasicSalary(3000);
		System.out.println("After increment the salary is ");
		e1.calculateGross();
		Employee e2=new Employee(2,"Srikanth",12000);
		e2.display();
		e2.calculateGross();
		e2.setBasicSalary(13000);
		System.out.println("After increment the salary is ");
		e2.calculateGross();
		e1.showCount();
		e2.showCount();
	}*/
    Employee eArr[]=new Employee[2];
    eArr[0]=new Employee(1,"Anita",2000);
    eArr[1]=new Employee(2,"Srikanth",12000);
    for(Employee e:eArr){
    	e.display();
    }
    
}
}
