package colections1;
public class Student implements Comparable<Student> {
private int rollno;
private String name;
private int marks;

public Student() {
	super();
}
public Student(int rollno, String name,int marks) {
	super();
	this.rollno = rollno;
	this.name = name;
	this.marks=marks;
}
public int getRollno() {
	return rollno;
}
public void setRollno(int rollno) {
	this.rollno = rollno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Override
public String toString() {
	return "Student rollno=" + rollno + ", name=" + name + "marks="+marks;
}
public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
@Override
public int compareTo(Student o) {
	// TODO Auto-generated method stub
	//return this.rollno-o.rollno;
	return this.name.compareTo(o.name);
	
}
@Override
public int hashCode() {
	/*final int prime = 31;
	int result = 1;
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	result = prime * result + rollno;
	return result;*/
	int value=31;
	int result=(31*rollno) + name.length();
	System.out.println(result);
	return result;
}
@Override
public boolean equals(Object obj) {
	System.out.println("In Equals method");
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Student other = (Student) obj;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	if (rollno != other.rollno)
		return false;
	return true;
}



}
