package com.cogni.orders;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cogni.model.Product;

/**
 * Servlet implementation class ConfirmOrder
 */
@WebServlet("/ConfirmOrder")
public class ConfirmOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ConfirmOrder() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(false);
		int total=0;
		ArrayList<Product> pList=(ArrayList<Product>) session.getAttribute("productlist");
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		out.println("<table border='1'>");
		for(Product p:pList){
			out.println("<tr");
			String m_pno=p.getPno();
			String m_pname=p.getPname();
			int m_price=p.getPrice();
			total += m_price;
			out.println("<td>"+m_pno+"</td>");
			out.println("<td>"+m_pname+"</td>");
			out.println("<td>"+m_price+"</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		out.println("<br>Total"+total);
		out.println("</body></html>");
		session.invalidate();	
		}
		
		
	}

	
	


