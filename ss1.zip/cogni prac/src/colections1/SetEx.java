package colections1;
import java.util.*;
public class SetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet<String> slset=new LinkedHashSet<>();
		String s="this is is sample That are are not correct correct";
        String[] str=s.split("\\s"); 
        for(String x:str){
        	slset.add(x);
        }
        //System.out.println(slset);
        StringBuffer sb=new StringBuffer();
        for(String y:slset){
        	sb.append(y+" ");
        }
        String s1=sb.toString();
        System.out.println(s1);
	}

}
