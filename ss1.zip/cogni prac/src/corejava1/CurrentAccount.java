package corejava1;

public class CurrentAccount extends Account {
    private String crn;
	public CurrentAccount() {
		// TODO Auto-generated constructor stub
		super();
	}
	public CurrentAccount(int acno, String name, float balance, String crn) {
		super(acno, name, balance);
		this.crn = crn;
	}
	public String getCrn() {
		return crn;
	}
    public void display(){
    	super.display();
    	System.out.println("CRN Number: "+crn);
    }
    public void withdraw(float amt){
    	if(balance-amt>5000){
			balance-=amt;
		}
		else{
			System.out.println("Insufficient Balance");
		}
    }
    public void deposit(float amt){
		balance = balance+amt;
		System.out.println("Amount deposited is: "+amt);
	}
	

}
