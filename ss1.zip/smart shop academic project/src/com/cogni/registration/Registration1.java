package com.cogni.registration;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cogni.model.Registration;
import com.cogni.service.RegistrationService;
import com.cogni.serviceimpl.RegistrationServiceImpl;

import java.io.*;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/Registration")
public class Registration1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registration1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String age=request.getParameter("age");
		String gender=request.getParameter("gender");
		String contactno=request.getParameter("cno");
		String uid=request.getParameter("id");
		String pass=request.getParameter("pwd");
		int m_age=Integer.parseInt(age);
		int m_contactno=Integer.parseInt(contactno);
		RegistrationService rService=new RegistrationServiceImpl();
		Registration rmodel=new Registration(fname, lname, m_age, m_contactno, gender, uid, pass);
		
		
		if(rService.insertUser(rmodel)){
		out.println("First Name is: "+fname);
		out.println("Last Name is: "+lname);
		out.println("Age is: "+age);
		out.println("Gender is: "+gender);
		out.println("Contact number is: "+contactno);
		out.println("User Name is: "+uid);
		}
		else{
			response.sendRedirect("Userlogin.html");
		}
	
	}

}
