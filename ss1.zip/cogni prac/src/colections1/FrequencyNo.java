package colections1;
import java.util.*;
public class FrequencyNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=0;
		Scanner s=new Scanner(System.in);
		HashMap<Integer,Integer> fmap=new HashMap<>();
		System.out.println("Enter the numbers");
        while(true){
			n=s.nextInt();
			if(n==-1){
				break;
			}
		    if(fmap.containsKey(n)){
		    	int freq=fmap.get(n);
		    	fmap.put(n, ++freq);
		    }
		    else{
		    	fmap.put(n, 1);
		    }
		}
		Set<Integer> keys=fmap.keySet();
		for(Integer k:keys){
			System.out.println(k+" frequency is "+fmap.get(k));
		}
	}
	
	

	}


