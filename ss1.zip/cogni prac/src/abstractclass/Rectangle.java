package abstractclass;

public class Rectangle implements Shape {
	int length;
	int breadth;
	
	public Rectangle() {
		super();
		length=5;
		breadth=4;
	}

	public Rectangle(int length, int breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}


	public void draw(){
		System.out.println("Rectangle is drawn with dimensions"+" "+length+"*"+breadth);
	}
	

}
