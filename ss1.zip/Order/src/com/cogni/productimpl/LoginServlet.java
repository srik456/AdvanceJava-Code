package com.cogni.productimpl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cogni.dao.LoginDao;
import com.cogni.model.Login;
import com.cogni.productimpl.LoginDaoImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String m_user1=request.getParameter("user");
		String m_pwd1=request.getParameter("pwd");
		ServletContext ctx=getServletContext();
		String m_url=ctx.getInitParameter("url");
		System.out.println(m_url);
		LoginDao ldao=new LoginDaoImpl();
		Login log=new Login(m_user1,m_pwd1);
		
		if(ldao.validateLogin(log)){
			RequestDispatcher rd=request.getRequestDispatcher("HomePageServlet");
			request.setAttribute("company","Cognizant");
			rd.forward(request,response);
			
			//out.println("Welcome "+m_user1);
		}
		else{
			//out.println("Invalid UserName/PassWord");
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			//rd.forward(request,response);
			//out.println("invalid username/password");
			rd.forward(request,response);
		}
	}

}
