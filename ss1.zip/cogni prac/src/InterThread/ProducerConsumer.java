package InterThread;

public class ProducerConsumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    Basket b=new Basket();
		Producer p=new Producer(b);
		Consumer c=new Consumer(b);
		p.start();
		c.start();
		

	}

}
