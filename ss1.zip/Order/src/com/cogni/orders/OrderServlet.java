package com.cogni.orders;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cogni.dao.ProductDao;
import com.cogni.model.Product;
import com.cogni.productimpl.ProductDaoImpl;


@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public OrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
			PrintWriter out =response.getWriter();
				ProductDao pDao=new ProductDaoImpl();
				ArrayList<Product> pList=pDao.getAllProducts();
				out.println("<html><body>");
				out.println("<form action='AddToCart' method='post'>");
				out.println("<select name='pid'>");
				for(Product p:pList){
					out.println("<option value="+p.getPno()+">"+p.getPname()+"  </option>");
				}
				out.println("</select>");
				out.println("<input type='submit'  value='AddToCart'>");
				out.println("</form></body></html>"); 
		 

	}

}
