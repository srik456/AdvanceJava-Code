package corejava1;

public class ArrayDemo {

	static void modify(int arr[])
	{
		for(int i=0;i<arr.length;i++){
			arr[i]+=2;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int arr[];//int []arr or int arr[]
		arr=new int[5];//arr[]={1,2,3}; or new[]{1,2,3}
		for(int i=0;i<arr.length;i++){
			System.out.println(arr[i]);
		}
		modify(arr);*/
		int twoarr[][]={{1,2},{4,5,6},{7,8,9,10}};//row size is mandatory,col size is not
		for(int i=0;i<twoarr.length;i++){
			for(int j=0;j<twoarr[i].length;j++){
				System.out.print(twoarr[i][j]+" ");
			}
			System.out.println();
		}

	}

}
