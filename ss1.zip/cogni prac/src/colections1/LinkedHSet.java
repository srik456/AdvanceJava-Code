package colections1;
import java.util.*;
public class LinkedHSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int n=0;
		LinkedHashSet<Integer> hset=new LinkedHashSet<>();
		
		System.out.println("Enter numbers");
		Scanner s=new Scanner(System.in);
		while(true){
			n=s.nextInt();
			if(n>=0){
				hset.add(n);
			}
			else{
				break;
			}
		}
		System.out.println(hset);*/
		HashSet<Integer> hset1=new HashSet<>();
		hset1.add(44);
		hset1.add(24);
		hset1.add(99);
		hset1.add(9);
		hset1.add(1);
		hset1.add(22);
		hset1.add(432);
		hset1.add(41);
		hset1.add(60);
		System.out.println(hset1);
		TreeSet<Integer> tset=new TreeSet<>();
		tset.add(44);
		tset.add(24);
		tset.add(99);
		tset.add(9);
		tset.add(1);
		tset.add(22);
		tset.add(432);
		tset.add(41);
		tset.add(60);
		System.out.println(tset);
		LinkedHashSet<Integer> hset=new LinkedHashSet<>();
		hset.add(43);
		hset.add(21);
		hset.add(32);
		hset.add(78);
		hset.add(9);
		hset.add(0);
		hset.add(65);
		hset.add(443);
		System.out.println(hset);

	}

}
