package Readerex;
import java.io.*;
public class MyEmployee implements Serializable{

	private int empno;
	private String name;
	private transient int salary;
	
	public MyEmployee() {
		super();
	}

	public MyEmployee(int empno, String name, int salary) {
		super();
		this.empno = empno;
		this.name = name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "empno=" + empno + ", name=" + name + ", salary=" + salary ;
	}
	

	

}
