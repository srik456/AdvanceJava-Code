package dateexercise;
import java.util.*;
import java.time.*;
public class LocalDateExercise {
    
	public void DateDetails(String date){
		LocalDate date1=LocalDate.parse(date);
		System.out.println("Year "+date1.getYear());
		System.out.println("Month "+date1.getMonth());
		System.out.println("Date "+date1.getDayOfMonth());
		System.out.println("Day of Week "+date1.getDayOfWeek());
		System.out.println("Day of Year "+date1.getDayOfYear());
		/*if(date1.getMonthValue()>=1&&date1.getMonthValue()<=3){
			System.out.println("Quarter 1");
		}
		else if(date1.getMonthValue()>=4&&date1.getMonthValue()<=6){
			System.out.println("Quarter 2");
		}
		else if(date1.getMonthValue()>=6&&date1.getMonthValue()<=9){
			System.out.println("Quarter 3");
		}
		else if(date1.getMonthValue()>=9&&date1.getMonthValue()<=12){
			System.out.println("Quarter 4");
		}*/
		switch(date1.getMonth()){
		case JANUARY:
		case FEBRUARY:
		case MARCH:
			System.out.println("In Quarter 1");break;
		case APRIL:
		case MAY:
		case JUNE:
			System.out.println("In Quarter 2");break;
		case JULY:
		case AUGUST:
		case SEPTEMBER:
			System.out.println("In Quarter 3");break;
		case OCTOBER:
		case NOVEMBER:
		case DECEMBER:
			System.out.println("In Quarter 4");break;
		}
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Date;
		Scanner s=new Scanner(System.in);
		LocalDateExercise obj =new LocalDateExercise();
		System.out.println("Enter Date in String seperated by -");
		Date=s.nextLine();
		obj.DateDetails(Date);
		

	}

}
