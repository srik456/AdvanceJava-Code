package corejava1;

public class TestEquals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s=new String("abc");
		String s1=new String("abc");
		/*if(s==s1){
			System.out.println("both refer to same object");
		}
		else{
			System.out.println("refers to different object");
		}*/
		/*if(s.equals(s1)){
			System.out.println("Equal");
		}
		else{
			System.out.println("Not Equal");
		}*/
		Employee emp=new Employee(1,"Asha",10000);
		

	}

}
