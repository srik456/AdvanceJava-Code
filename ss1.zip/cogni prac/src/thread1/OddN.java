package thread1;
import java.util.*;
public class OddN extends Thread{
private int odd;
private ArrayList<Integer> al=new ArrayList<>();

public OddN(int odd, ArrayList<Integer> al) {
	super();
	this.odd = odd;
	this.al = al;
}
public void run(){
	for(int i=1;i<odd;i=i+2){
	
			al.add(i);
		}
	
	for(Integer x:al){
		System.out.println(x);
	}
	try {
		Thread.sleep(100);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
