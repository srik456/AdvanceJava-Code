package thread1;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;
import java.util.zip.InflaterInputStream;
class Main1{
	    public static void main(String args[]){
	        String s1;
	        int n;
	       // Scanner s=new Scanner(System.in);
	        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	        ArrayList<String> al=new ArrayList<>();
	        
	        n=s.nextInt();
	        for(int i=0;i<n;i++){
	            s1=br.readLine();
	            al.add(s1);
	        }
	        HashSet<String> hs=new HashSet<>(al);
	        System.out.println(hs.size());
	    }
	}

