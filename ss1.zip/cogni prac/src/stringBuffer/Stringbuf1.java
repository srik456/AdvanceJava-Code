package stringBuffer;

public class Stringbuf1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Hello World times 100000";
		StringBuffer sb=new StringBuffer(s);
		System.out.println(sb.reverse());
		String s1=sb.toString();
		System.out.println(s1);

	}

}
