document.write("<h1>In external JS</h1>");
