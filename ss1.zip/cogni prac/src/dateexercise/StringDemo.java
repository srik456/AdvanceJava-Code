package dateexercise;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String s="abc",s1;//BLK 1
		System.out.println(s);
		s1=s.toUpperCase();
		System.out.println(s1);
		System.out.println(s+" "+s.toUpperCase());*/
	/*	String a="Anita",c="anita";
		String b=a.toLowerCase();
		int count=0;
		for(int i=0;i<a.length();i++){
			if(b.charAt(i)=='a'||b.charAt(i)=='e'||b.charAt(i)=='o'||b.charAt(i)=='i'||b.charAt(i)=='u'){
				count++;
			}
		}
		System.out.println(count);*/
		/*for(int i=0;i<a.length();i++){
		System.out.println(a.codePointAt(i));

	}*/
		/*System.out.println(a.equals(c));
		System.out.println(a.equalsIgnoreCase(c));
		System.out.println(a.compareTo(c));
		System.out.println(a.compareToIgnoreCase(c));*/
		/*String s="HelloWorld";
		System.out.println(s.indexOf('o'));
		System.out.println(s.lastIndexOf('o'));
		String s1=s.substring(5);
		System.out.println(s1);
		System.out.println(s.startsWith("Hel"));
		System.out.println(s.endsWith("rld"));*/
		String s2="RAM";
		String s3="SRIKANTH";
		/*s3=s2.concat(s3);
        System.out.println(s3);
        System.out.println(s2.contains("ani"));
        String s7="";
        System.out.println(s7.isEmpty());*/
		/*String s4=s3.replace("SRI", "RAM");
		System.out.println(s4);
		int x=10;
		String number=String.valueOf(x);
		System.out.println(number.length());
		String s10="    asdfsd    ";
		System.out.println(s10);
		String s11=s10.trim();
		System.out.println(s11);
		String s12="101:SRIKANTH:RAM:DEVELOPER:1000000000";
		String sArr[]=s12.split(":");
		for(int i=0;i<sArr.length;i++){
			String s=sArr[i];
			if(s.equals("1000000000")){
				int sal=Integer.parseInt(s);
				sal+=11234455;
				System.out.println(sal);
			}
		}*/
		/*String a="101:SRIKANTH:DEVELOPER:1000000000;102:Anita:Tester:200000";
		String sArr[]=a.split(";");
		int total=0;
		for(int i=0;i<sArr.length;i++){
			String sArr1[]=sArr[i].split(":");
			for(int j=0;j<sArr1.length;j++){
				System.out.println(sArr1[j]);
				if(j==3){
					total += Integer.parseInt(sArr1[j]);
				}
			}
		}
		System.out.println("Total sal "+total);*/
		String empno="123456a";
		boolean flag=false;
		for(int i=0;i<empno.length();i++){
			if(!Character.isDigit(empno.charAt(i))){
				flag=true;
				break;
			}
		}
		if(flag==true){
			System.out.println("empno is alphanumeric");
		}
		else{
			System.out.println("empo is numeric");
		}
		
}
}
