package InterThread;

public class Consumer extends Thread{
	Basket v;

	
	public Consumer() {
		super();
	}
	public Consumer(Basket v) {
		super();
		this.v = v;
	}
	public void run(){
		for(int i=0;i<10;i++){
			v.getNum();
		}
	}

}
