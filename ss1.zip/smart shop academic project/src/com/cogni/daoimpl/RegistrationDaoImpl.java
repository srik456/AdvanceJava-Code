package com.cogni.daoimpl;
import com.cogni.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cogni.dao.RegistrationDao;
import com.cogni.model.Registration;
public class RegistrationDaoImpl implements RegistrationDao{

	@Override
	public boolean insert(Registration reg) {
		// TODO Auto-generated method stub
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="insert into UserLogin values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, reg.getFirstname());
			pst.setString(2, reg.getLastname());
			pst.setInt(3, reg.getAge());
			pst.setString(4,reg.getGender());
			pst.setInt(5,reg.getContactno());
			pst.setString(6,reg.getUserid());
			pst.setString(7,reg.getPassword());
			int rec=pst.executeUpdate();
			if(rec>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}

	public Registration getUser(String m_userid){
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="select * from UserLogin where userid=?";
		Registration reg1=null;
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, m_userid);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
			String v_firstname=rs.getString(1);
			String v_lastname=rs.getString(2);
			int v_age=rs.getInt(3);
			String v_gender=rs.getString(4);
			int v_cno=rs.getInt(5);
			String v_password=rs.getString(6);
			reg1=new Registration(v_firstname, v_lastname, v_age, v_cno, v_gender, m_userid, v_password);
			return reg1;
			}
			else{
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
		
	}
	@Override
	public boolean update(Registration reg) {
		// TODO Auto-generated method stub
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		String query="update set firstname=?,lastname=?,age=?,contact_number=?,password=? from where userid=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1,reg.getFirstname());
			ps.setString(2,reg.getLastname());
			ps.setInt(3,reg.getAge());
			
			ps.setInt(4,reg.getContactno());
			ps.setString(5,reg.getPassword());
			ps.setString(6,reg.getUserid());
			int rec=ps.executeUpdate();
			if(rec==1){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

}
