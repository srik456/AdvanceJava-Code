package methodoverloading;

public class Employee {
	private int empno;
	private String name;
	private int bsalary;
	public Employee(int empno, String name, int bsalary) {
		super();
		this.empno = empno;
		this.name = name;
		this.bsalary = bsalary;
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBsalary() {
		return bsalary;
	}
	public void setBsalary(int bsalary) {
		this.bsalary = bsalary;
	}
	public float calGross(){
		float ta=bsalary*0.1f;
		float da=bsalary*0.15f;
		float hra=bsalary*0.05f;
		float gs=bsalary+ta+da+hra;
		return gs;
	}
}
