package Readerex;
import java.io.*;
public class ExWrite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedWriter out=null;
		BufferedReader in=null;
		String input=null;
		try{
			out=new BufferedWriter(new FileWriter("d:\\Sriktxt.txt",true));
			in=new BufferedReader(new InputStreamReader(System.in));
			while(true){
				input=in.readLine();
				if(input.equalsIgnoreCase("quit")){
					break;
				}
				out.write(input);
				out.newLine();
			}
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				in.close();
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
