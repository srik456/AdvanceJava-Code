package MThread;

public class HighLowDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		High h=new High();
		Low l=new Low();
		h.start();
		l.start();

	}

}
