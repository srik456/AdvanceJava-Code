package corejava1;

public class TestAccount {

	static void print(Account account){
		System.out.println("Bank Of Maharashtra");
		System.out.println("Hinjewadi Branch");
		account.display();
		System.out.println("-----------------------------");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*SavingsAccount sacc=new SavingsAccount(101,"Srikanth",50000,false);
		sacc.display();
		sacc.deposit(10000);
		System.out.println("Current Balance "+sacc.getBalance());
		sacc.withdraw(59500);
		System.out.println("Current Balance "+sacc.getBalance());
		Account cacc=new CurrentAccount(101,"Srikanth",75000,"Axzc234");
		cacc.display();
		cacc.deposit(6000);
		System.out.println("Current Balance "+cacc.balance);
		cacc.withdraw(15000);
		System.out.println("Current Balance "+cacc.balance);*/
		/*Account acc=new SavingsAccount(101,"Anita",500,false);
		print(acc);*/
		/*System.out.println(((SavingsAccount)acc).isSenior());
		SavingsAccount ac=(SavingsAccount) acc;
		System.out.println(ac.isSenior());*/
		/*CurrentAccount acc1=new CurrentAccount(102,"Sudhir",10000,"Abs1234");
		print(acc1);*/
		Account sArr[]=new Account[2];
		sArr[0]=new SavingsAccount(101,"Anita",500,false);
		sArr[1]=new CurrentAccount(102,"Sudhir",10000,"Abs1234");
		for(Account ac:sArr){
			//ac.display();
			print(ac);
		}
	}

}
