package methodoverloading;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
public class EmployeeTest {
	Employee e1;
	@Before
	public void setUp() throws Exception {
		e1=new Employee(1,"Srikanth",1000);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
	    assertEquals(1300, e1.calGross(),0.0);
		//fail("Not yet implemented");
	}

}
