package com.cogni.home;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/UserController")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UserController() {
        super();
        // TODO Auto-generated constructor stub
    }

		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String m_operation=request.getParameter("operation");
		System.out.println(m_operation);
		if(m_operation.equals("update")){
			RequestDispatcher rd=request.getRequestDispatcher("updateuser.html");
			rd.forward(request, response);
		}
		else if(m_operation.equals("display")){
			RequestDispatcher rd=request.getRequestDispatcher("DisplayUserServlet.html");
			rd.forward(request, response);
		}
	}

}
