package com.cogni.model;

public class Login {
	private String userid,password;

	
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Login(String userid, String password) {
		super();
		this.userid = userid;
		this.password = password;
	}


	public String getUserid() {
		return userid;
	}


	public void setUserid(String userid) {
		this.userid = userid;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
