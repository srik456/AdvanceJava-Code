package abstractclass;

public abstract class Vehicle {
	private String regNo;
	private String vMake;
	private String color;
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Vehicle(String regNo, String vMake, String color) {
		super();
		this.regNo = regNo;
		this.vMake = vMake;
		this.color = color;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getRegNo() {
		return regNo;
	}
	public String getvMake() {
		return vMake;
	}
	public String toString(){
		return regNo+" "+vMake+" "+color;
	}
	public void start(){
		
	}
	public void stop(){
		
	}
}
