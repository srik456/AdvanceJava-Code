package MThread;

public class Low extends Thread{
	public Low(){
		setPriority(MIN_PRIORITY);
	}
	public void run(){
		int i=0;
		while(i<100){
			System.out.println("low "+i);
			i++;
		}
	}

}
