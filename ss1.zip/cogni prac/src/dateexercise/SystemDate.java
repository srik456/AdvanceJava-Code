package dateexercise;
import java.util.*;

public class SystemDate {
	public static void main(String args[]) {
		/*Date today=new Date();
		System.out.println(today);
		Date today1=new Date();
		System.out.println(today1);
		Calendar tomorrow=Calendar.getInstance();
		//tomorrow.set(2019, 1, 22);
		tomorrow.set(Calendar.MONTH, 4);
		tomorrow.set(Calendar.DATE, 15);
		tomorrow.set(Calendar.YEAR, 2019);
		Date d_tom=tomorrow.getTime();
		System.out.println(d_tom);
		System.out.println(d_tom.after(today));
		System.out.println(d_tom.before(today));
		System.out.println(d_tom.compareTo(today1));*/
		Calendar today=Calendar.getInstance();
		System.out.println(today);
		Date today5=new Date();
		today.set(Calendar.MONTH, 4);
		today.set(Calendar.DATE, 15);
		today.set(Calendar.YEAR, 2019);
		today.add(Calendar.DATE, 5);
		today5=today.getTime();
		System.out.println(today5);
		
	

}
}
