package com.cogni.util.copy;
import java.sql.*;
public class JdbcConnection {
	public static Connection getConnection(String url){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String user="HR";
		String password="hr";
		Connection con=null;
		try {
			con=DriverManager.getConnection(url,user,password);
			if(con!=null){
				System.out.println("Connected");//testing for connection
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	

}
