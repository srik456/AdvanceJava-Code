package interfaceb;

public interface Shape {

}
