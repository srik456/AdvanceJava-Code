package jdbcex;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
public class EmpApp1 {

	public static void insert(){
		int empno=7;
		String name="leena";
		int sal=7500;
		Emp emp= new Emp(empno,name,sal);
		EmpDao empDao=new EmpDaoImpl();
		boolean flag=empDao.insertRec(emp);
		if(flag){
			System.out.println("Record Inserted");
		}
		else{
			System.out.println("Record not Inserted");
		}
	}
	public  static void delete(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter empno to be deleted");
		int empno=sc.nextInt();
		EmpDao edao=new EmpDaoImpl();
		boolean flag=edao.deleteRec(empno);
		if(flag==true){
			System.out.println("Record Deleted");
		}
		else{
			System.out.println("Record not Deleted");
		}
	}
	public static void search(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter empno to search");
		int empno=sc.nextInt();
		EmpDao ed=new EmpDaoImpl();
		boolean flag=ed.SearchRec(empno);
		if(flag==true){
			System.out.println("Record Found");
		}
		else{
			System.out.println("Record not Found");
		}
	}
	public static void displayAll(){
		EmpDao edao=new EmpDaoImpl();
		ArrayList<Emp> eList=edao.getAllRec();
		if(!(eList.isEmpty())){
			for(Emp e:eList){
				System.out.println(e);
			}
		}
		else{
			System.out.println("Table is Empty");
		}
	}
	public static void update(){
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter name to be updated");
		try {
		String name=br.readLine();
		System.out.println("Enter updated salary");
		int sal=Integer.parseInt(br.readLine());
		System.out.println("Enter empno");
		int empno=Integer.parseInt(br.readLine());
		EmpDao ed=new EmpDaoImpWithPrep();
		boolean flag=ed.updateRec(empno,name,sal);
		if(flag==true){
			System.out.println("Record Found");
		}
		else{
			System.out.println("Record not Found");
		}
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*insert();
		delete();
		search();*/
		//getEmp();
		//displayAll();
		update();
	
	}
	

}
