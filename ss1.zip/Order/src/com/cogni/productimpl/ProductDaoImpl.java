package com.cogni.productimpl;
import com.cogni.dao.ProductDao;
import java.sql.*;
import java.util.*;
import com.cogni.model.Product;
import com.cogni.util1.JdbcConnection;
public class ProductDaoImpl implements ProductDao{

	@Override
	public ArrayList<Product> getAllProducts() {
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="select * from product";
		ArrayList<Product> pList=null;
		try {
				PreparedStatement pst;
				pst = con.prepareStatement(query);
				ResultSet rs=pst.executeQuery();
				pList=new ArrayList<>();
				while(rs.next()){
					String m_pno=rs.getString(1);
					String m_pname=rs.getString(2);
					int m_price=rs.getInt(3);
					Product p=new Product(m_pno,m_pname,m_price);
					pList.add(p);
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			

		
	
        return pList;
	}
	public Product getProduct(String pid){
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="select * from product where pid=?";
		int price=0;
		
			PreparedStatement pst;
			try {
				pst = con.prepareStatement(query);
				pst.setString(1, pid);
				ResultSet rs=pst.executeQuery();
				rs.next();
				String m_no=rs.getString(1);
				String m_pname=rs.getString(2);
				price=rs.getInt(3);
				Product p=new Product(m_no,m_pname,price);
				return p;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return null;
	}
}
