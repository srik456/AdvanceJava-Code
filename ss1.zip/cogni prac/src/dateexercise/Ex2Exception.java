package dateexercise;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Ex2Exception {
    static void input(){
    	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    	System.out.println("Enter name");
    	try{
    		String name=br.readLine();
    		System.out.println("Your Name is: "+name);
    	}
    	catch(IOException e){
    		e.printStackTrace();
    	}
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*String s="123aa";
		int num1=12;
		int num2=2;
		int arr[]={1,2,4};
		try{
			try{
				
			
			int result=num1/num2;
			int x=Integer.parseInt(s);
			}
		catch(ArithmeticException e){
			System.out.println(e);
		}

	}catch(NumberFormatException e){
		System.out.println(e);
	}*/
		input();
	
}
}
