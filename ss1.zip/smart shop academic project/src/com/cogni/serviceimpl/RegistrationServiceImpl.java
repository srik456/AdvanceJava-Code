package com.cogni.serviceimpl;

import com.cogni.dao.RegistrationDao;
import com.cogni.daoimpl.RegistrationDaoImpl;
import com.cogni.model.Registration;
import com.cogni.service.RegistrationService;

public class RegistrationServiceImpl implements RegistrationService{

	@Override
	public boolean insertUser(Registration reg) {
		// TODO Auto-generated method stub
		RegistrationDao rdao=new RegistrationDaoImpl();
		return rdao.insert(reg);
	}
	

}
