package abstractclass;

public class Circle implements Shape{
	private int radius;

	
	public Circle(int radius) {
		super();
		this.radius = radius;
	}


	public Circle() {
		super();
		radius=5;
	}
	public void draw(){
		System.out.println("Circle is drawn with radius"+" "+radius);
	}
	
}
