package bokk;
import java.util.*;
import java.io.*;
public class BookMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
