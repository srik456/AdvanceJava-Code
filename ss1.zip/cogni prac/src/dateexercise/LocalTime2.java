package dateexercise;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class LocalTime2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*LocalTime lt=LocalTime.now();
		LocalTime lt1=LocalTime.now();
		System.out.println(lt.isAfter(lt1.of(14, 32, 23)));
		System.out.println(lt1.isBefore(lt.of(12, 45, 10)));*/
		/*LocalTime start=LocalTime.of(15,34,43);
		LocalTime end=LocalTime.of(10,43,12);
		Duration d=Duration.between(start, end);
		System.out.println(d);*/
		/*LocalDate lt=LocalDate.of(1997,Month.OCTOBER,4);
		LocalDate lt1=LocalDate.of(2019,Month.FEBRUARY,22);
		Period p=Period.between(lt, lt1);
		long p2=ChronoUnit.DAYS.between(lt, lt1);
		System.out.println("You are: "+p.getYears()+" years, "+p.getMonths()+" months, "+p.getDays()+" days old. ("+p2+" days total)");*/
	    ZonedDateTime currentTime=ZonedDateTime.now();
	    ZonedDateTime currentTimeInParis=ZonedDateTime.now(ZoneId.of("Europe/Paris"));
	    ZonedDateTime currentTimeInNewYork=ZonedDateTime.now(ZoneId.of("America/New_York"));
	    
	    System.out.println("India:"+currentTime);
	    System.out.println("France:"+currentTimeInParis);
	    System.out.println("New York:"+currentTimeInNewYork);
	    
	}
	

}
