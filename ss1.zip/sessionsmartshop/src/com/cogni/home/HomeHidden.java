package com.cogni.home;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/HomeHidden")
public class HomeHidden extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public HomeHidden() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String m_username=request.getParameter("username");
		String m_color=request.getParameter("color");
		PrintWriter out=response.getWriter();
		out.println("<html><body bgcolor="+m_color+">");
		out.println("<form action='HiddenNextPage1' method='post'>");
		out.println("<input type='hidden' name='husername' value="+m_username+">");
		out.println("<input type='hidden' name='hcolor' value="+m_color+">");
		out.println("<h2>Welcome on HomeHidden &nbsp;&nbsp;"+m_username+"</h2>");
		out.println("<input type='submit' value='Page1'>");
		out.println("</form></body></html>");
	}

}
