package ebox;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

public class Main {
public static void main(String args[]) {
	HashMap<Integer,Player> hm=new HashMap<Integer,Player>();
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	try {
		int num =Integer.parseInt((br.readLine()));
		
		
		for(int i=0;i<num;i++){
			System.out.println("Enter the details of the player "+i );
			int j_no=Integer.parseInt(br.readLine());
			String pname=br.readLine();
			String tname=br.readLine();
			String type=br.readLine();
			Player p=new Player(j_no,pname,tname,type);
			hm.put(i,p);
		}
	} catch (NumberFormatException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
