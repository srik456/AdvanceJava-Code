package com.cogni.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cogni.dao.RegistrationDao;
import com.cogni.daoimpl.RegistrationDaoImpl;

public class UpdateUser {
	RegistrationDao rd=new RegistrationDaoImpl();
	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		rd.getUser("srik123");
		assertNotNull(rd);
	}

}
