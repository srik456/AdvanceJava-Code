package methodoverloading;

public class TestCalc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator.add(67, 3);
		Calculator.add(4.0f, 654.0f);
		Calculator.add(34.50, 56.75);

	}

}
