import java.util.*;
import java.text.*;
public class SDF {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String date="2-02-2016";
		String pattern="dd-MM-yyyy";
		SimpleDateFormat sdf=new SimpleDateFormat(pattern);
		try{
			Date d2=sdf.parse(date);
			System.out.println(sdf.format(d2));
			String npattern="dd-MM-yyyy hh mm ss a";
			SimpleDateFormat sdf1=new SimpleDateFormat(npattern);
			System.out.println(sdf1.format(d2));
			
		}
		catch(ParseException e){
			e.printStackTrace();
		}

	}

}
