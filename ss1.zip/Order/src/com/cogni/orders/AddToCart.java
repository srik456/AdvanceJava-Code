package com.cogni.orders;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cogni.dao.ProductDao;
import com.cogni.model.Product;
import com.cogni.productimpl.ProductDaoImpl;




@WebServlet("/AddToCart")
public class AddToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public AddToCart() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String m_pid=request.getParameter("pid");
		ProductDao pDao=new ProductDaoImpl();
		HttpSession session=request.getSession();

		ArrayList<Product> pList=(ArrayList<Product>)session.getAttribute("productlist");
		//ArrayList<String> pList=new ArrayList();
		if(pList==null){
			pList=new ArrayList<Product>();
		}
		Product product=pDao.getProduct(m_pid);
		pList.add(product);
		session.setAttribute("productlist",pList);
		out.println("<html><body>");
		out.println("You have ordered <br>");
		for(Product p:pList){
			out.println(p.getPno()+" "+p.getPname());
		}
		
		out.println("<a href='OrderServlet'>Back</a>");
		out.println("<a href='ConfirmOrder'>Confirm Order</a>");
		out.println("</body></html>");
	}

}
