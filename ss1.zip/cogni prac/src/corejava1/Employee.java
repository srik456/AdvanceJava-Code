package corejava1;

public class Employee {
	private int empno;
	private String name;
	private int basicSalary;
	static int count=0;
    static int seedValue;
	public Employee() {
		super();
		count++;
		// TODO Auto-generated constructor stub
	}
	static{
		seedValue=100;
		System.out.println("Seed Value"+" "+seedValue);
	}
	static{
		System.out.println("Second Block");
	}

	public Employee(int empno, String name, int basicSalary) {
		super();
		this.empno = ++seedValue;
		this.name = name;
		this.basicSalary = basicSalary;
		Employee.count++;
	}

	public void calculateGross() {
		float grossSalary;
		float ta = 0.1f;
		float da = 0.15f;
		float hra = 0.2f;
		grossSalary = basicSalary + (basicSalary * ta) + (basicSalary * da) + (basicSalary * hra);
		System.out.println("Gross Salary:" + grossSalary);
	}

	public void display() {
		System.out.println(empno + " " + name + " " + basicSalary);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}

	public int getEmpno() {
		return empno;
	}
	public static void showCount(){
		   System.out.println(count);
	   }
	
}
