package thread1;
import java.util.*;
public class ArrayListThread extends Thread{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ArrayList<Integer> al=new ArrayList<>();
        System.out.println("Starting Main Thread");
        OddN o=new OddN(20,al);
        EvenN ev=new EvenN(20,al);
        o.start();
        ev.start();
        System.out.println("before o "+o.isAlive());
		System.out.println("before ev "+ev.isAlive());
		try {
			ev.join();
			o.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("o "+o.isAlive());
		System.out.println("v "+ev.isAlive());
		System.out.println("Ending Main Thread");
        
	}

}
