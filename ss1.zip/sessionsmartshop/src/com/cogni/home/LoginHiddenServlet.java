package com.cogni.home;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginHiddenServlet")
public class LoginHiddenServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginHiddenServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String m_username=request.getParameter("username");
		String m_password=request.getParameter("password");
		String m_color=request.getParameter("color");
		if(m_username.equals("admin")&&m_password.equals("admin")){
			RequestDispatcher rd=request.getRequestDispatcher("HomeHidden");
			rd.forward(request, response);
		}
		else{
			response.sendRedirect("loginhidden.html");
		}
	}

}
