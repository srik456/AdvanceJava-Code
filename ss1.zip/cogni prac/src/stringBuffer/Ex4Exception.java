package stringBuffer;

public class Ex4Exception {
    static void method3(){
    	int x=12/0;
    }
    static void method2(){
    	method3();
    }
    static void method1(){
    	method2();
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        try{
        	method1();
        }catch(ArithmeticException e){
        	System.out.println(e);
        }
	}

}
