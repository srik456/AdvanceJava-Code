package setproblems;
import java.util.*;
public class IndexBuilder {
    public TreeSet<Index> buildIndex(HashSet<Player> hp){
    	Index<qqqq	>
    	return null;
    	
    }
    public Index findIndex(TreeSet<Index> ts,char ch){
    	return null;
    }
    public void displayIndex(TreeSet<Index> ts){
    	
    }
}

