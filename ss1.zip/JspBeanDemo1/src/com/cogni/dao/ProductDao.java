package com.cogni.dao;
import java.util.*;

import com.cogni.model.Product;
public interface ProductDao {
	ArrayList<Product> getAllProducts();
	Product getProduct(String pid);
	boolean insertProduct(Product product);
}
