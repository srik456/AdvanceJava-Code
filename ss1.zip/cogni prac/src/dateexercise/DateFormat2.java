package dateexercise;
import java.util.*;
import java.text.*;
public class DateFormat2 {
	public static void main(String args[]){
		Calendar today= Calendar.getInstance();
		Date tomorrow=new Date();
		DateFormat df= DateFormat.getDateInstance(DateFormat.LONG);
		today.add(Calendar.DATE, 1);
		tomorrow=today.getTime();
		System.out.println(tomorrow);
		
	}

}
