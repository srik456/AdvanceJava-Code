package dateexercise;
import java.util.*;
import java.text.*;

public class DateFormat3 {
	public void day(int dayofweek){
		switch(dayofweek){
		case 1:System.out.println("Sunday");break;
		case 2:System.out.println("Monday");break;
		case 3:System.out.println("Tuesday");break;
		case 4:System.out.println("Wednesday");break;
		case 5:System.out.println("Thursday");break;
		case 6:System.out.println("Friday");break;
		case 7:System.out.println("Saturday");break;
		default:System.out.println("Enter valid day");
		
		}
		
	}
	
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int date,year,month;
        int dayofweek;
        int df;
		Date d=new Date();
		Calendar cdate=Calendar.getInstance();
		Scanner s=new Scanner(System.in);
		DateFormat3 df3=new DateFormat3();
		date=s.nextInt();
		year=s.nextInt();
		month=s.nextInt();
		dayofweek=s.nextInt();
		cdate.set(year, month, date);

		System.out.println(cdate.get(Calendar.DATE));
		System.out.println(cdate.get(Calendar.MONTH));
		System.out.println(cdate.get(Calendar.YEAR));
		System.out.println(cdate.get(Calendar.HOUR));
		df3.day(dayofweek);
	}

}
