package new1;

public class Revenue implements Comparable<Revenue>{
   String revenueCategory;
   int amount;

   public Revenue() {
	super();
}

public Revenue(String revenueCategory, int amount) {
	super();
	this.revenueCategory = revenueCategory;
	this.amount = amount;
}

public String getRevenueCategory() {
	return revenueCategory;
}

public void setRevenueCategory(String revenueCategory) {
	this.revenueCategory = revenueCategory;
}

public Integer getAmount() {
	return amount;
}

public void setAmount(int amount) {
	this.amount = amount;
}


@Override
public String toString() {
	return revenueCategory + "\t\t" + amount;
}

public int compareTo(Revenue o) {
	// TODO Auto-generated method stub
	if(amount==o.getAmount())  
		return 0;  
		else if(amount>o.getAmount())  
		return 1;  
		else  
		return -1;  
	
}
}
