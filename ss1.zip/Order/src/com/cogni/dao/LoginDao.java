package com.cogni.dao;

import com.cogni.model.Login;

public interface LoginDao {
	boolean validateLogin(Login login);
	

}
