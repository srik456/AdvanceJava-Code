package colections1;
import java.util.ArrayList;
import java.util.Collections;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Student> slist=new ArrayList<>();
		Student s=new Student(3,"Veena",100);
		slist.add(s);
		slist.add((new Student(2,"Hello",70)));
		slist.add((new Student(1,"Leena",50)));
		for(Student s1:slist){
			System.out.println(s1);
		}
		System.out.println("After Sorting");
	    Collections.sort(slist,new MarksSorter());
	    for(Student s1:slist){
			System.out.println(s1);
		}
		

	}

}
