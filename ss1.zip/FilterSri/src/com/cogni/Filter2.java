package com.cogni;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Filter2 implements Filter {


    public Filter2() {
        
    }

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		PrintWriter x=response.getWriter();
		x.println("Filter 2 sending request to MyServlet");
		chain.doFilter(request, response);
		x.println("Filter 2 returning back to the client");
		
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
