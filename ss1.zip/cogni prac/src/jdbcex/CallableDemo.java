package jdbcex;
import java.sql.*;
public class CallableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e){
			System.out.println(e);
		}
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String user="HR";
		String password="hr";
		Connection con=null;
		try {
			con=DriverManager.getConnection(url,user,password);
			String query="{call insrtrecord(?,?,?,?,?)}";
			CallableStatement cst=con.prepareCall(query);
			int  empno=4;
			String f_name="Neema";
			String l_name="Gupta";
			int sal=2300;
			int deptno=10;
			cst.setInt(1, empno);
			cst.setString(2, f_name);
			cst.setString(3, l_name);
			cst.setInt(4, sal);
			cst.setInt(5, deptno);
			cst.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
