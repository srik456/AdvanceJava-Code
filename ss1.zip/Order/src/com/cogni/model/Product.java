package com.cogni.model;

public class Product {
	private String pno;
	private String pname;
	private int price;
	public Product(String pno, String pname, int price) {
		super();
		this.pno = pno;
		this.pname = pname;
		this.price = price;
	}
	public String getPno() {
		return pno;
	}
	public void setPno(String pno) {
		this.pno = pno;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	

}
