package com.cogni.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cogni.service.RegistrationService;
import com.cogni.serviceimpl.RegistrationServiceImpl;

public class RegistrationTest1 {
    com.cogni.model.Registration reg=null;
    RegistrationService rservice;
	@Before
	public void setUp() throws Exception {
		reg = new com.cogni.model.Registration("srik","nara",23,99999121,"Male","srik123","1234xyz");
		rservice=new RegistrationServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		assertTrue(rservice.insertUser(reg));
	}

}
