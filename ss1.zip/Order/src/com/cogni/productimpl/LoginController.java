package com.cogni.productimpl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cogni.dao.LoginDao;
import com.cogni.model.Login;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public LoginController() {
        super();
       
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	     PrintWriter out=response.getWriter();
         
         String m_user=request.getParameter("username");
         String m_password=request.getParameter("password");
         
         
         Login login=new Login(m_user,m_password);
         LoginDao logindao=new LoginDaoImpl();
         if(logindao.validateLogin(login)){
          HttpSession session=request.getSession();
          session.setAttribute("username", m_user);
          session.setAttribute("password", m_password);
          RequestDispatcher rd=request.getRequestDispatcher("order.jsp");
          rd.forward(request, response);
                     
         }
         
         
         else{
                     RequestDispatcher rd=request.getRequestDispatcher("login.html");
                     out.println("Invalid user name password");
                     rd.include(request, response);
         
         }

	}


	}


