package thread1;

public class YourThread extends Thread{
	private int end;
		// TODO Auto-generated method stub
		public void run(){
			for(int i=1;i<=end;i++){
				System.out.println(2*i);
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public YourThread(int end) {
			super();
			this.end = end;
		}

	}


