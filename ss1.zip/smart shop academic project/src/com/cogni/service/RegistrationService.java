package com.cogni.service;

import com.cogni.model.Registration;

public interface RegistrationService {
	public boolean insertUser(Registration reg);

}
