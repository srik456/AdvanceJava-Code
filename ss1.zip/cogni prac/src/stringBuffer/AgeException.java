package stringBuffer;

public class AgeException extends Exception{
    private int age;

	public AgeException(int age) {
		super();
		this.age = age;
	}
    public String toString(){
    	return "Invalid  exception"+age;
    }
    static void validateAge(int x) throws AgeException{
    	if(x>=22&&x<=60){
    		System.out.println("Valid age");
    	}
    	else{
    		throw new AgeException(x);
    	}
    }
    public static void main(String args[]){
    	try{
    		validateAge(12);
    	}catch(AgeException e){
    		e.printStackTrace();
    	}
    }

}
