package com.cogni.dao;

import com.cogni.model.Registration;

public interface RegistrationDao {
	public boolean insert(Registration reg);
	public boolean update(Registration reg1);
	public Registration getUser(String m_userid);

}
