package questions;

public interface LibraryUser {
	void registerAccount();
	void requestBook();

}
