package MThread;

public class High extends Thread{

	public High() {
		super();
		setPriority(MAX_PRIORITY);
	}
	public void run(){
		int i=0;
		while(i<100){
			System.out.println("High "+i);
			i++;
		}
		
	}

	

}
