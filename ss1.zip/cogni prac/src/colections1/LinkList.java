package colections1;
import java.util.*;
public class LinkList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*LinkedList<Integer> aList=new LinkedList<>();
		aList.add(10);
		aList.add(20);
		aList.add(30);
		aList.add(40);
		aList.add(50);
		aList.add(0);
		ListIterator<Integer>Itr=aList.listIterator(aList.size());
		while(Itr.hasPrevious()){
			System.out.println(Itr.previous());
		}
		System.out.println("------------------------");
		while(Itr.hasNext()){
			System.out.println(Itr.next());
		}

	}
*/
		
		
}
}
