package colections1;
import java.util.*;
impo
import java.text.ParseException;
import java.text.SimpleDateFormat;
class UserMainCode{
	     void displayDate(String s1){
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	        Date d=sdf.parse(s1);
	        Calendar c=Calendar.getInstance();
	        c.getTime();
	        c.add(Calendar.MONTH,-12);
	        c.add(Calendar.MONTH,-8);
	        c.add(Calendar.YEAR,-2);
	        System.out.println("20 months before "+d+"will be "+.()+"-"c.getMonth()+"-"c.getDate());
	        
	        
	        
	    }
	}


}
