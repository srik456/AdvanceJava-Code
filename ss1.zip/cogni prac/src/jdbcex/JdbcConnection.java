package jdbcex;
import java.sql.*;
public class JdbcConnection {
	public static Connection getConnection(){
		Connection con=null;
		String url="jdbc:mysql://localhost:3306/srikdb";
		String user="root";
		String password="root";
		try{
			con=DriverManager.getConnection(url,user,password);
		}catch(SQLException e){
			System.out.println(e);
		}
		return con;
	}

}
