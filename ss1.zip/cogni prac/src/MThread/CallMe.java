package MThread;

import java.io.IOException;

public class CallMe extends Thread{
    
	public void print(String msg){
		//synchronized(this){
		System.out.print("["+msg);
		try{
			Thread.sleep(1000);
		}catch(InterruptedException e){
			System.out.println(e);
		}
		System.out.println("]");
	}
	//}

}
