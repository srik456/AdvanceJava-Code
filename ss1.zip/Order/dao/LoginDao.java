package com.cogni.dao;

public interface LoginDao {
	boolean validateLogin(String user,String password,String url);
	

}
