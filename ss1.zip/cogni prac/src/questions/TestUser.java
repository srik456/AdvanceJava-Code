package questions;

public class TestUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AdultUser a=new AdultUser(23, "Fiction");
		KidUser k=new KidUser(5,"Kids");
		a.registerAccount();
		a.requestBook();
		k.registerAccount();
		k.requestBook();
		

	}

}
