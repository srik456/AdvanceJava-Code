package jdbcex;

public class EmpApp2 {
	public static void insert(){
		int empno=7;
		String name="leena";
		int sal=7500;
		Emp emp= new Emp(empno,name,sal);
		EmpDao empDao=new EmpDaoImpl();
		boolean flag=empDao.insertRec(emp);
		if(flag){
			System.out.println("Record Inserted");
		}
		else{
			System.out.println("Record not Inserted");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
