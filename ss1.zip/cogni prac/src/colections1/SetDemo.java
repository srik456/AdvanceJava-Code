package colections1;
import java.util.*;
public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*HashSet<Integer>hSet=new HashSet<>();
		hSet.add(9);
		hSet.add(2);
		hSet.add(3);
		hSet.add(3);
		hSet.add(9);
		hSet.add(989);
		hSet.add(99);
		System.out.println("hSet : "+hSet);
		hSet.remove(9);
		System.out.println(hSet);*/
		HashSet<Student>hSet=new HashSet<>();
		Student s=new Student(201,"Anita");
		hSet.add(s);
		Student s1=new Student(101,"Anita");
		hSet.add(s1);
		Student s2=new Student(201,"Anita");
		hSet.add(s2);
		System.out.println(hSet);

	}

}
