package MThread;

public class CallmeRunner extends Thread{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CallMe cm=new CallMe();
		ThreadM t1=new ThreadM(cm,"Hello");
		ThreadM t2=new ThreadM(cm,"World");
		t1.start();
		t2.start();

	}

}
