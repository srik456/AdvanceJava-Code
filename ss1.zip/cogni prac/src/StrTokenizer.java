import java.util.StringTokenizer;
public class StrTokenizer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="102 Anita";
		StringTokenizer st=new StringTokenizer(s);
		String rollno=st.nextToken();
		String name=st.nextToken();
		Student student=new Student(Integer.parseInt(rollno),name);

	}

}
