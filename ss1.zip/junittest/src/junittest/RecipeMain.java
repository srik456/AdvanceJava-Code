package junittest;
import java.util.*;
import java.io.*;
public class RecipeMain {
public static void showMenu(){
	System.out.println("1.Add recipe");
	System.out.println("2.Remove recipe");
	System.out.println("3.Show Recipes");
	System.out.println("4.Exit");
}
public static Recipe inputRecipe() throws RecipeException{
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	String m_name = null,m_price=null,m_coffee=null,m_milk=null,m_sugar=null,m_chocolate=null;
	String x="";
	String [] sar=new String[15];
	System.out.println("Enter the details in single line");
    try {
		x=br.readLine();
		sar=x.split(" ");
		m_name=sar[0];
		m_price=sar[1];
		m_coffee=sar[2];
		m_milk=sar[3];
		m_sugar=sar[4];
		m_chocolate=sar[5];
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	Recipe rec=new Recipe();
	rec.setName(m_name);
	rec.setPrice(m_price);
	rec.setAmtCoffee(m_coffee);
	rec.setAmtMilk(m_milk);
	rec.setAmtSugar(m_sugar);
	rec.setAmtChocolate(m_chocolate);
	return rec;
	
}
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String response;
		char choice;
		RecipeBook rb=new RecipeBook();
		while(true){
			showMenu();
			System.out.println("Enter choice");
			choice=br.readLine().charAt(0);
			try{
			switch(choice){
			case '1':Recipe respie=inputRecipe();
			         if(rb.addRecipe(respie)){
			        	 System.out.println("Recipe Added");
			         }
			         else{
			        	 System.out.println("Recipe not added");
			         }
			         break;
			case '2':System.out.println("Enter coffee name to be deleted");
			         String n=br.readLine();
			         if(rb.deleteRecipe(n)){
			        	 System.out.println("Element removed successfully");
			         }
			         else{
			        	 System.out.println("Element not removed");
			         }
			         break;
			case '3':rb.showRecipes();break;
			case '4':System.exit(0);break;	
			}
			}catch(RecipeException e){
				System.out.println(e);
			}
			/*System.out.println("Do you wish to continue");
			response=br.readLine();
			if(response.equalsIgnoreCase())*/
		}
	}

}
