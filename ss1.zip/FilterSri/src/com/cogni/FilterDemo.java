package com.cogni;

import java.io.*;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet Filter implementation class FilterDemo
 */
public class FilterDemo implements Filter {
    BufferedReader in;
    /**
     * Default constructor. 
     */
    public FilterDemo() {
        // TODO Auto-generated constructor stub
    	
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	protected boolean checkList(String m_user){
		String line=null;
		try {
			while((line=in.readLine())!=null){
				if(line.equals(m_user)){
					System.out.println("In if");
					return true;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
        PrintWriter out=response.getWriter();
		String m_user=request.getParameter("username");
        if(!checkList(m_user)){
		// pass the request along the filter chain
		chain.doFilter(request, response);
        }
        else{
        	out.println("<html><body>");
        	out.println("<h3>Access Denied</h3>");
        	out.println("</body></html>");
        }
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
		String m_file=fConfig.getInitParameter("userfile");
		
			try {
				in=new BufferedReader(new FileReader(m_file));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}

}
