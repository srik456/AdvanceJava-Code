package abstractclass;

public class TestShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape sarr[]=new Shape[3];
		sarr[0]=new Rectangle();
		sarr[1]=new Circle();
		sarr[2]=new Triangle();
		for(Shape s1:sarr){
			System.out.println(sarr);
		}
		for(Shape s1:sarr){
			s1.draw();
		}
		

	}

}
