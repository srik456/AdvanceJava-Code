package com.cogni.impl;

import com.cogni.dao.LoginDao;
import com.cogni.util.JdbcConnection;

import java.sql.*;
public class LoginDaoImpl implements LoginDao{

	public boolean validateLogin(String user, String password,String url) {
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		con=JdbcConnection.getConnection(url);
		String query="select * from login where userid=? and password=?";
		try {
			ps = con.prepareStatement(query);
			ps.setString(1, user);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			if(rs != null){
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (ps != null){
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con != null){
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;
	}

}
