package abstractclass;

public class TestVehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	  Vehicle vArr[]=new Vehicle[2];
	  vArr[0]=new Car("Ab1234", "maruti", "Orange", 5);
	  vArr[1]=new Truck("Ab3456", "mahindra", "Red", 100);
	  for(Vehicle v:vArr){
		  System.out.println(v);
	  }
	  for(Vehicle v:vArr){
		  v.start();
	  }
	  

	}

}
