package MThread;
import java.applet.*;
public class EvenThread extends Applet implements Runnable{
	public void run(){
		for(int i=2;i<=10;i=i+2){
			System.out.println(i);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
