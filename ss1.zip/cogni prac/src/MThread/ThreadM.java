package MThread;

public class ThreadM extends Thread{
	CallMe c;
    String msg;
	public ThreadM(CallMe c, String msg) {
		super();
		this.c = c;
		this.msg = msg;
	}
	public void run(){
		synchronized(c){
		c.print(msg);
		}
	
}
}
