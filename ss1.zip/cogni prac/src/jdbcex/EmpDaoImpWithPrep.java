package jdbcex;
import java.sql.*;
import java.util.ArrayList;

public class EmpDaoImpWithPrep implements EmpDao{



	@Override
	public boolean insertRec(Emp emp) {
		// TODO Auto-generated method stub
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="insert into emp values(?,?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setInt(1, emp.getEmpno());
			pst.setString(2, emp.getName());
			pst.setInt(3, emp.getSal());
			int rec=pst.executeUpdate();
			if(rec==1){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean deleteRec(int empno) {
		// TODO Auto-generated method stub
		Connection con=null;
		con=JdbcConnection.getConnection();
		try{
			String query="delete from emp where empno=?";
			PreparedStatement pst=con.prepareStatement(query);
			int rec=pst.executeUpdate(query);
			if(rec==1){
				return true;
			}
			
		}catch(SQLException e){
			System.out.println(e);
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public boolean SearchRec(int empno) {
		// TODO Auto-generated method stub
		Connection con=null;
		con=JdbcConnection.getConnection();
			try{
				String query1="select empno from emp where empno="+empno;
				PreparedStatement pst=con.prepareStatement(query1);
				ResultSet rs=pst.executeQuery(query1);
				if(rs.next()){
					return true;
				}
				
			}catch(SQLException e){
				System.out.println(e);
			}
			finally{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		

		return false;
	
}

	@Override
	public Emp getEmployee(int empno) {
		// TODO Auto-generated method stub
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="select * from emp where empno=?";
		
		return null;
	}

	@Override
	public ArrayList<Emp> getAllRec() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateRec(int empno, String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateRec(int empno, int sal) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateRec(int empno, String name, int sal) {
		// TODO Auto-generated method stub
		Connection con=null;
		con=JdbcConnection.getConnection();
		try{
			String query1="update emp set name=?,salary=? where empno=?";
			PreparedStatement pst=con.prepareStatement(query1);
			pst.setString(1,name);
			pst.setInt(2, sal);
			pst.setInt(3, empno);
			int i=pst.executeUpdate(query1);
			if(i==1){
				return true;
			}
			System.out.println("Records updated");
		}catch(SQLException e){
			System.out.println(e);
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
    
	return false;
		
	}

	
	

}
