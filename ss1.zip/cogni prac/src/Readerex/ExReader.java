package Readerex;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ExReader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileReader in =null;
		long start=0,end=0;
				try{
					in=new FileReader("d:\\Sriktxt.txt");
					int ch;
					start=System.currentTimeMillis();
					while( (ch=in.read())!=-1 ){
						System.out.print((char)ch);
						
						
					}
					end=System.currentTimeMillis();
				}catch(FileNotFoundException e){
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally{
					try {
						in.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				System.out.println("Total time "+(end-start));

	}

}
