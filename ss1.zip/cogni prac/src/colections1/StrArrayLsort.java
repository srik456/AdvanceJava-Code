package colections1;
import java.util.*;
public class StrArrayLsort{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> sList=new ArrayList<>();
		sList.add("Hello");
		sList.add("Come on");
		sList.add("om");
		sList.add("Hi");
		sList.add("Bye");
		sList.add("ta-ta");
		sList.add("Later");
	    System.out.println("--------------");
	    

	}

	

}
