package abstractclass;

public class Triangle implements Shape{
	private int base,height;

	
	public Triangle() {
		super();
		base=3;
		height=5;
	}


	public Triangle(int base, int height) {
		super();
		this.base = base;
		this.height = height;
	}


	
	public void draw(){
		System.out.println("Triangle is drawn with base"+" "+base+" "+"and height"+" "+height);
	}
	

}
